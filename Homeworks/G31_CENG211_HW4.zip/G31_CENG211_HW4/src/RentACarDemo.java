public class RentACarDemo {
	public static void main(String[] args) {
		
		RentingCompany company = new RentingCompany();
		company.simulateRentingCompany();
		
		
	}
}