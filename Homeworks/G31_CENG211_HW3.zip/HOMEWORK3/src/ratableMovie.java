public interface ratableMovie {

	 /**
	 interface for a movies critic 
	  that contains rateMovie method's method body
	 */
	
	  public double rateMovie(Movie movie);
	
}
