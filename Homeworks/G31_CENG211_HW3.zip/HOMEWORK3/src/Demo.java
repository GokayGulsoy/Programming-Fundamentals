public class Demo {
	public static void main(String[] args) {
	
		Company comp = new Company();
		comp.simulateRatingCompany();
			

	}

}
